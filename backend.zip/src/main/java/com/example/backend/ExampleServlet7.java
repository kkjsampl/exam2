package com.example.backend;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/mvc7")
public class ExampleServlet7 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int value1 = Integer.parseInt(request.getParameter("value1"));
		int value2 = Integer.parseInt(request.getParameter("value2"));
		String op = request.getParameter("op");
		int result = value1 + value2;
		String oper = "덧셈";
		if(op.equals("*")) {
			result = value1 * value2;
			oper = "곱셈";
		} else if(op.equals("-")) {
			result = value1 - value2;
			oper = "뺄셈";
		}
		
		request.setAttribute("value1", value1);
		request.setAttribute("value2", value2);
		request.setAttribute("oper", oper);
		request.setAttribute("result", result);
		
		RequestDispatcher rd = request.getRequestDispatcher("/result7.jsp");
		rd.forward(request, response);
	}
}
