package com.example.backend;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/mvc1")
public class ExampleServlet1 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		request.setAttribute("name", name);
		RequestDispatcher rd = request.getRequestDispatcher("/result1.jsp");
		rd.forward(request, response);
	}
}
