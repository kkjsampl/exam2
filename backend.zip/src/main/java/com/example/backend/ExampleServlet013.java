package com.example.backend;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/rest3")
public class ExampleServlet013 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int value = Integer.parseInt(request.getParameter("value"));
		int result = value * value;
		
		PrintWriter out = response.getWriter();
		out.println(result);
		out.flush();
	}
}
