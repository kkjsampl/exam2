package com.example.backend;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

import com.google.gson.*;


@WebServlet("/rest5")
public class ExampleServlet015 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double height = Integer.parseInt(request.getParameter("height"))/100.0;
		double maleWeight = height * height * 22;
		double femaleWeight = height * height * 21;
		
		Map<String, Object> map = new HashMap<>();
		map.put("maleWeight", maleWeight);
		map.put("femaleWeight", femaleWeight);
		
		PrintWriter out = response.getWriter();
		out.println(new Gson().toJson(map));
		out.flush();
	}
}
