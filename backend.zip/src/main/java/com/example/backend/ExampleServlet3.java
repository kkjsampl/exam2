package com.example.backend;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/mvc3")
public class ExampleServlet3 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int value = Integer.parseInt(request.getParameter("value"));
		int result = value * value;
		request.setAttribute("value", value);
		request.setAttribute("result", result);
		RequestDispatcher rd = request.getRequestDispatcher("/result3.jsp");
		rd.forward(request, response);
	}
}
