package com.example.backend;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

import com.google.gson.*;


@WebServlet("/rest7")
public class ExampleServlet017 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json;charset=utf-8");
		int value1 = Integer.parseInt(request.getParameter("value1"));
		int value2 = Integer.parseInt(request.getParameter("value2"));
		String op = request.getParameter("op");
		int result = value1 + value2;
		String oper = "덧셈";
		if(op.equals("*")) {
			result = value1 * value2;
			oper = "곱셈";
		} else if(op.equals("-")) {
			result = value1 - value2;
			oper = "뺄셈";
		}
		
		Map<String, Object> map = new HashMap<>();
		map.put("oper", oper);
		map.put("result", result);
		
		PrintWriter out = response.getWriter();
		out.println(new Gson().toJson(map));
		out.flush();
	}
}
