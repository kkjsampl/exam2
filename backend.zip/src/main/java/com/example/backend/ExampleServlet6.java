package com.example.backend;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/mvc6")
public class ExampleServlet6 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int height = Integer.parseInt(request.getParameter("height"));
		double ki = height/100.0;
		String gender = request.getParameter("gender");
		double weight = ki * ki * 21;
		if(gender.equals("남자"))
			weight += ki;
		request.setAttribute("gender", gender);
		request.setAttribute("height", height);
		request.setAttribute("weight", weight);
		RequestDispatcher rd = request.getRequestDispatcher("/result6.jsp");
		rd.forward(request, response);
	}
}
