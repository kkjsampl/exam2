package com.example.backend;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/rest6")
public class ExampleServlet016 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int height = Integer.parseInt(request.getParameter("height"));
		double ki = height/100.0;
		String gender = request.getParameter("gender");
		double weight = ki * ki * 21;
		if(gender.equals("남자"))
			weight += ki;
		
		PrintWriter out = response.getWriter();
		out.println(weight);
		out.flush();
	}
}
