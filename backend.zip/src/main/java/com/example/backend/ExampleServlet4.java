package com.example.backend;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/mvc4")
public class ExampleServlet4 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int value1 = Integer.parseInt(request.getParameter("value1"));
		int value2 = Integer.parseInt(request.getParameter("value2"));
		int result = value1 + value2;
		request.setAttribute("value1", value1);
		request.setAttribute("value2", value2);
		request.setAttribute("result", result);
		RequestDispatcher rd = request.getRequestDispatcher("/result4.jsp");
		rd.forward(request, response);
	}
}
