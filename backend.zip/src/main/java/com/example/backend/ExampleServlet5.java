package com.example.backend;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/mvc5")
public class ExampleServlet5 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double height = Integer.parseInt(request.getParameter("height"))/100.0;
		double maleWeight = height * height * 22;
		double femaleWeight = height * height * 21;
		request.setAttribute("maleWeight", maleWeight);
		request.setAttribute("femaleWeight", femaleWeight);
		RequestDispatcher rd = request.getRequestDispatcher("/result5.jsp");
		rd.forward(request, response);
	}
}
