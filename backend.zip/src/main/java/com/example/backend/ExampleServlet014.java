package com.example.backend;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/rest4")
public class ExampleServlet014 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int value1 = Integer.parseInt(request.getParameter("value1"));
		int value2 = Integer.parseInt(request.getParameter("value2"));
		int result = value1 + value2;
		
		PrintWriter out = response.getWriter();
		out.println(result);
		out.flush();
	}
}
